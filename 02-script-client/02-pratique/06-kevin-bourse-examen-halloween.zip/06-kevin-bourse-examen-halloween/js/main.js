// Réaliser une application qui analyse
// un paragraphe fourni par l’utilisateur et calcule des
// statistiques de mots.

// 1. Longueur du texte: le paragraphe doit
// contenir entre 50 et 300 mots(espaces
// multiples et ponctuation autorisées)
///////////////////////////////////////
// 2. Top 3 longueurs de mots: afficher
// les trois longueurs de mots les plus fréquentes
// (ex : 4 lettres, 5 lettres, etc.).
// En cas d’égalité, afficher toutes les
// longueurs ex æquo, avec leur nombre d’occurrences
///////////////////////////////////////
// 3. Moyenne: afficher la moyenne des occurrences
// du « top 3 » (ou du top étendu s’il y a
// des égalités)

// Réflexion Algorythmique Personelle :

// 1 ) faire une saisie de la phrase et l'afficher. OK
// 2 ) stocker la phrase dans un tableau et les séparer. OK
// 3 ) vérifier si l'utilisateur entre bien un para-
// graphe compris entre 50 et 300 mots. OK.
// 4 ) Faire un compteur pour les 3 longeur
// de mot les plus long pour pouvoir les affiché avec
// Le nombre de fois.
 
let paragraphe = prompt("Veuillez entrer un paragraphe entre 50 et 300 mots");

console.log(typeof(paragraphe)); // Type de donnée (apprise en autodidacte)

let paragrapheTableau = paragraphe.split(" "); // Séparation de la chaine
// de caractère sous forme d'index et du mot associé dans le tableau. 

console.log(typeof (paragrapheTableau)); // Type de donnée (apprise en autodidacte)

if (paragrapheTableau.length < 50) {
    console.log("Veuillez entrer au moins 50 mots");
} else {
    console.log(`Voici vos 50 mots et plus : ${paragrapheTableau} `);
}

/////////////
// a suivre: gèrer l'erreur avec les points et les espaces,
// ne pas les comptabilisé dans les mots du tableau 
/////////////

// renvoyé le mot le plus long du tableau ci-dessous
// for (let i = 0; paragrapheTableau.length; i++){
// }





